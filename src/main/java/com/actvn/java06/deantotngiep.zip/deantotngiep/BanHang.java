
package com.actvn.java06.deantotngiep;

import java.util.ArrayList;
import java.util.Scanner;
import java.time.LocalDate;
import java.util.Collection;
import java.util.Collections;
import java.util.Objects;
class BanHang {

    private ArrayList<SanPham> danhSachSanPhamDaBan;
    
    private int soLuongBan;
    public BanHang() {
        danhSachSanPhamDaBan = new ArrayList<>();
    }

    public BanHang(ArrayList<SanPham> danhSachSanPhamDaBan) {
        this.danhSachSanPhamDaBan = danhSachSanPhamDaBan;
    }
    

   
    

    public void banSanPham(DanhSachSanPham danhSachSanPham) {
         Scanner sc = new Scanner(System.in);
        System.out.println("Nhap ma san pham can ban: ");
        String maSanpham = sc.nextLine();

        SanPham spCanBan = danhSachSanPham.timSanPhamTheoMa(maSanpham);

        if (spCanBan != null) {
            System.out.println("Nhap so luong san pham ban muon ban: ");
             soLuongBan = sc.nextInt();

            if (soLuongBan <= spCanBan.getSoLuong()) {
                spCanBan.setSoLuong(spCanBan.getSoLuong() - soLuongBan);

                SanPham spDaBan = new SanPham(spCanBan.getMaSP(),
                        spCanBan.getTen(),
                        spCanBan.getNhaSX(),
                        soLuongBan,
                        spCanBan.getGia(),
                        spCanBan.getNSX(),
                        spCanBan.getHSD());

                danhSachSanPhamDaBan.add(spDaBan);

                System.out.println("Ban hang thanh cong!");
            } else {
                System.out.println("Khong du hang de ban!");
            }
        } else {
            System.out.println("Khong tim thay san pham trong kho!");
        }
    }

    public void inSanPhamDaBan() {
        System.out.println("Danh sach san pham da ban:");
        for (SanPham sp : danhSachSanPhamDaBan) {
            System.out.println(sp);
        }
    }

    public int getSoLuongBan() {
        return soLuongBan;
    }

    public void setSoLuongBan(int soLuongBan) {
        this.soLuongBan = soLuongBan;
    }
    

     
    public boolean kiemTraHanSuDung(SanPham sp) {
        LocalDate ngayHienTai = LocalDate.now();
        return ngayHienTai.isBefore(sp.getHSD());
    }
     public double tinhTongTien() {
        double tongTien = 0;
        for (SanPham sp : danhSachSanPhamDaBan) {
            tongTien += sp.getGia() * sp.getSoLuong();
        }
        return tongTien;
    }
     
    
  
}

